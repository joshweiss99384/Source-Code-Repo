  <footer class="main-footer">
    <strong><a href="#">Government Bank Locker Management System</a>.</strong>

  </footer>
